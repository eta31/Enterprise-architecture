package edu.mum.dao;

import edu.mum.domain.Item;

public interface ItemDao extends GenericDao<Item> {
      
}
